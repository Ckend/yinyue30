from django.apps import AppConfig


class ExtractorConfig(AppConfig):
    name = 'extractor'
